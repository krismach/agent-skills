# Rule Title

## Section

Category Name

## Summary

One sentence summary of the rule.

## Incorrect

```javascript
// Bad example
```

## Correct

```javascript
// Good example
```

## Why

Explanation of why this matters and the performance impact.
